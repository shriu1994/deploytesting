from django.db import models
from django.urls import reverse
from django.core.exceptions import FieldDoesNotExist

# Create your models here.

attribute_choice = (
    ('0','No Finding'),   
    ('1','Atelectasis'),('2','Cardiomegaly'), ('3','Consolidation'),
    ('4','Covid 19'), ('5','Edema'),('6','Emphysema'),
    ('7','Fibrosis'), ('8','Infiltration'), ('9','Mass'),
    
    ('q','Nodule'), ('w','Pleural Effusion'),
    ('e','Pleural Thickening'), ('t','Pneumonia'),
    ('a','Pneumothorax'), ('s','Soft tissue Emphysema'),
    
)

class ImageDetails(models.Model):

    img= models.ImageField(upload_to='pics')
    labels = models.CharField(max_length=100, choices=attribute_choice,default='0')
    comment = models.TextField(default='')
    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    
    # def __str__(self):
    #     return self.name

    def get_absolute_url(self):
        return reverse('home')