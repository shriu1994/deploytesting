from django.forms import ModelForm
from .models import ImageDetails, attribute_choice
from django import forms

  
class UpdateForm(forms.Form):
    labels = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple,
                                          choices=attribute_choice)
    comment = forms.CharField(widget=forms.Textarea, required=False)