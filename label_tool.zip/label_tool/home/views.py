from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import FieldDoesNotExist

from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    DeleteView
)
from .models import ImageDetails
from .forms import UpdateForm
# from .filters import ImageFilter

def is_valid_queryparam(param):
    return param != '' and param is not None

def filter(request):
  
    qs = ImageDetails.objects.all().order_by('id')
    id_exact = request.GET.get('id_exact')
    if id_exact == "":
        id_exact = request.GET.get('id_exact')
       
    elif isinstance(id_exact,str):
    # else:
        id_exact = tuple(map(int, id_exact.split('-')))
        if len(id_exact)!=1:
            id_exact = range(id_exact[0],id_exact[1]+1)

    # print(id_exact)

    id_min = request.GET.get('id_min')
    id_max = request.GET.get('id_max')
    date_min = request.GET.get('date_min')
    date_max = request.GET.get('date_max')

    if is_valid_queryparam(id_exact):
        qs = qs.filter(id__in=id_exact)
    if is_valid_queryparam(date_min):       
        qs = qs.filter(date_created__gte=date_min)

    
    if is_valid_queryparam(date_max):
        qs = qs.filter(date_created__gte=date_max)


    return qs
           


class ImageListView(LoginRequiredMixin, ListView):
    # myfilter = ImageFilter(request.GET, )
    model = ImageDetails
    template_name = 'home/home.html'
    context_object_name = 'objects'
    ordering = ['id']
    paginate_by = 5
    
    def get_queryset(self):
        return filter(self.request)
    
        
class ImageDetailView(LoginRequiredMixin, DetailView):
    model = ImageDetails
    # template_name = 'contactlist/user1.html'
    
class ImageCreateView(LoginRequiredMixin,CreateView):
    model = ImageDetails
    fields = ['img']


@login_required
def ImageUpdate(request, pk):
    obj = ImageDetails.objects.get(id=pk)
    if request.method == 'POST':
        form = UpdateForm(request.POST)
        if form.is_valid():
            labels = form.cleaned_data.get('labels')
            comment = form.cleaned_data.get('comment')
            obj.labels = labels
            obj.comment = comment
            # print(type(obj.labels))
            obj.save()
            return redirect('/')
    else:
        form = UpdateForm
    return render(request,'home/updateform.html', {'form':form, 'obj':obj})


class ImageDeleteView(LoginRequiredMixin, DeleteView):
    model = ImageDetails
    success_url = '/'