from django.urls import path
from .views import (
  ImageListView,
  ImageCreateView,
  ImageDetailView,
  ImageUpdate,
  ImageDeleteView 
)

urlpatterns = [
    path('',ImageListView.as_view(),name = 'home'),
    path('details/<int:pk>/',ImageDetailView.as_view(), name='details'),
    path('create/',ImageCreateView.as_view(), name='create'),
    path('details/<int:pk>/update',ImageUpdate, name='update'),
    path('details/<int:pk>/delete/',ImageDeleteView.as_view(), name='delete'),
]


